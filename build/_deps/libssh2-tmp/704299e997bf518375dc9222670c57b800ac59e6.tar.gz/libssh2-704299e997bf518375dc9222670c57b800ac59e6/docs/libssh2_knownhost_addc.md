---
c: Copyright (C) Daniel Stenberg
SPDX-License-Identifier: BSD-3-Clause
Title: libssh2_knownhost_addc
Section: 3
Source: libssh2
See-also:
  - libssh2_knownhost_check(3)
  - libssh2_knownhost_free(3)
  - libssh2_knownhost_init(3)
---

# NAME

libssh2_knownhost_addc - add a known host

# SYNOPSIS

~~~c
#include <libssh2.h>

int
libssh2_knownhost_addc(LIBSSH2_KNOWNHOSTS *hosts,
                       char *host, char *salt,
                       char *key, size_t keylen,
                       const char *comment, size_t commentlen,
                       int typemask,
                       struct libssh2_knownhost **store);
~~~

# DESCRIPTION

Adds a known host to the collection of known hosts identified by the 'hosts'
handle.

*host* is a pointer the host name in plain text or hashed. If hashed, it
must be provided base64 encoded. The host name can be the IP numerical address
of the host or the full name.

If you want to add a key for a specific port number for the given host, you
must provide the host name like '[host]:port' with the actual characters '['
and ']' enclosing the host name and a colon separating the host part from the
port number. For example: "[host.example.com]:222".

*salt* is a pointer to the salt used for the host hashing, if the host is
provided hashed. If the host is provided in plain text, salt has no meaning.
The salt has to be provided base64 encoded with a trailing zero byte.

*key* is a pointer to the key for the given host.

*keylen* is the total size in bytes of the key pointed to by the *key*
argument

*comment* is a pointer to a comment for the key.

*commentlen* is the total size in bytes of the comment pointed to by the *comment* argument

*typemask* is a bitmask that specifies format and info about the data
passed to this function. Specifically, it details what format the host name is,
what format the key is and what key type it is.

The host name is given as one of the following types:
LIBSSH2_KNOWNHOST_TYPE_PLAIN, LIBSSH2_KNOWNHOST_TYPE_SHA1 or
LIBSSH2_KNOWNHOST_TYPE_CUSTOM.

The key is encoded using one of the following encodings:
LIBSSH2_KNOWNHOST_KEYENC_RAW or LIBSSH2_KNOWNHOST_KEYENC_BASE64.

The key is using one of these algorithms:
LIBSSH2_KNOWNHOST_KEY_RSA1, LIBSSH2_KNOWNHOST_KEY_SSHRSA or
LIBSSH2_KNOWNHOST_KEY_SSHDSS (deprecated).

*store* should point to a pointer that gets filled in to point to the
known host data after the addition. NULL can be passed if you do not care about
this pointer.

# RETURN VALUE

Returns a regular libssh2 error code, where negative values are error codes
and 0 indicates success.

# AVAILABILITY

Added in libssh2 1.2.5

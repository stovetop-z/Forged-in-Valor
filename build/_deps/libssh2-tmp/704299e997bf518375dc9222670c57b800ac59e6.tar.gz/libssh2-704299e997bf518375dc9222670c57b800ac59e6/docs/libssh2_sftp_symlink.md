---
c: Copyright (C) The libssh2 project and its contributors.
SPDX-License-Identifier: BSD-3-Clause
Title: libssh2_sftp_symlink
Section: 3
Source: libssh2
See-also:
  - libssh2_sftp_symlink_ex(3)
---

# NAME

libssh2_sftp_symlink - convenience macro for *libssh2_sftp_symlink_ex(3)*

# SYNOPSIS

~~~c
#include <libssh2.h>
#include <libssh2_sftp.h>

#define libssh2_sftp_symlink(sftp, orig, linkpath) \
    libssh2_sftp_symlink_ex((sftp), (orig), strlen(orig), (linkpath), \
                            strlen(linkpath), LIBSSH2_SFTP_SYMLINK)
~~~

# DESCRIPTION

This is a macro defined in a public libssh2 header file that is using the
underlying function *libssh2_sftp_symlink_ex(3)*.

# RETURN VALUE

See *libssh2_sftp_symlink_ex(3)*

# ERRORS

See *libssh2_sftp_symlink_ex(3)*
